from setuptools import setup

setup(name='example_probability',
      version='1.3',
      description='Gaussian and Binomial distributions',
      packages=['example_probability'],
      author = 'Andrew Paster',
      author_email = 'myemail@something.com',
    zip_safe=False)