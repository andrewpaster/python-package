from setuptools import setup

setup(name='example_probability',
      version='1.4',
      description='Gaussian and Binomial distributions',
      long_description='A simple example Python package with classses for binomial and Gaussian distributions',
      packages=['example_probability'],
      author = 'Andrew Paster',
      author_email = 'myemail@something.com',
    zip_safe=False)